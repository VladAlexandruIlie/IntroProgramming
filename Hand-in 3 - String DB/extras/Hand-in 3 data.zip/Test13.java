
import java.util.*;
import java.lang.reflect.*;

public class Test13 {
	public static void main(String[] args) {
		StringDB db = new StringDB();
		db.execute("INSERT INTO teachers VALUES ( 'Troels_Bjerre_Lund' , 'trbj' ) ;");
		System.out.println();
	}
}

