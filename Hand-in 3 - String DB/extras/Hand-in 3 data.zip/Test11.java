
import java.util.*;
import java.lang.reflect.*;

public class Test11 {
	public static void main(String[] args) {
		StringDB db = new StringDB();
		db.execute("CREATE TABLE orders ( OrderID varchar , CustomerID varchar , EmployeeID varchar , OrderDate varchar , ShipperID varchar ) ;");
		System.out.println();
	}
}

