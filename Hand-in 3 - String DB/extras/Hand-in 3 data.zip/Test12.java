
import java.util.*;
import java.lang.reflect.*;

public class Test12 {
	public static void main(String[] args) {
		StringDB db = new StringDB();
		db.execute("INSERT INTO courses VALUES ( 'Introductory_Programming' ) ;");
		System.out.println();
	}
}

