
import java.util.*;
import java.lang.reflect.*;

public class Test16 {
	public static void main(String[] args) {
		StringDB db = new StringDB();
		db.execute("INSERT INTO customers VALUES ( '2' , 'Ana_Trujillo_Emparedados_y_helados' , 'Ana_Trujillo' , 'Avda._de_la_Constitución_2222' , 'México_D.F.' , '05021' , 'Mexico' ) ;");
		System.out.println();
	}
}

