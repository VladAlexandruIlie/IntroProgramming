
import java.util.*;
import java.lang.reflect.*;

public class Test22 {
	public static void main(String[] args) {
		StringDB db = new StringDB();
		db.execute("SELECT OrderID AS OrderID , CustomerName AS CustomerName INTO result FROM joined ;");
		System.out.println();
	}
}

