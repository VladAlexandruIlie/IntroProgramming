
import java.util.*;
import java.lang.reflect.*;

public class Test07 {
	public static void main(String[] args) {
		StringDB db = new StringDB();
		db.execute("DROP TABLE chair ;");
		System.out.println();
	}
}

