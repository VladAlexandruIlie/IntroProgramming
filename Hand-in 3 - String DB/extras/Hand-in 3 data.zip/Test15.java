
import java.util.*;
import java.lang.reflect.*;

public class Test15 {
	public static void main(String[] args) {
		StringDB db = new StringDB();
		db.execute("INSERT INTO customers VALUES ( '1' , 'Alfreds_Futterkiste' , 'Maria_Anders' , 'Obere_Str._57' , 'Berlin' , '12209' , 'Germany' ) ;");
		System.out.println();
	}
}

