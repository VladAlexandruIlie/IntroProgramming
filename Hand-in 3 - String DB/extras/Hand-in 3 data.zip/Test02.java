
import java.util.*;
import java.lang.reflect.*;

public class Test02 {
	public static void main(String[] args) {
		StringDB db = new StringDB();
		db.execute("SELECT * FROM teachers ;");
		System.out.println();
	}
}

