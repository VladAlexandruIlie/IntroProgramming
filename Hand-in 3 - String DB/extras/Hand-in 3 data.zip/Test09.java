
import java.util.*;
import java.lang.reflect.*;

public class Test09 {
	public static void main(String[] args) {
		StringDB db = new StringDB();
		db.execute("CREATE TABLE teachers ( name varchar , username varchar ) ;");
		System.out.println();
	}
}

