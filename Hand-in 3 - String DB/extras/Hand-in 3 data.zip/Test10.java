
import java.util.*;
import java.lang.reflect.*;

public class Test10 {
	public static void main(String[] args) {
		StringDB db = new StringDB();
		db.execute("CREATE TABLE customers ( ID varchar , CustomerName varchar , ContactName varchar , Address varchar , City varchar , PostalCode varchar , Country varchar ) ;");
		System.out.println();
	}
}

