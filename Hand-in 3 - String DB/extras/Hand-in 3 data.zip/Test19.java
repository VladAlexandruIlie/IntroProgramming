
import java.util.*;
import java.lang.reflect.*;

public class Test19 {
	public static void main(String[] args) {
		StringDB db = new StringDB();
		db.execute("INSERT INTO orders VALUES ( '10309' , '37' , '3' , '1996-09-19' , '1' ) ;");
		System.out.println();
	}
}

