
import java.util.*;
import java.lang.reflect.*;

public class Test03 {
	public static void main(String[] args) {
		StringDB db = new StringDB();
		db.execute("SELECT * FROM customers ;");
		System.out.println();
	}
}

