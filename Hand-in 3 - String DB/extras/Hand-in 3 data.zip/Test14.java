
import java.util.*;
import java.lang.reflect.*;

public class Test14 {
	public static void main(String[] args) {
		StringDB db = new StringDB();
		db.execute("INSERT INTO teachers VALUES ( 'Martin_Aumüller' , 'maau' ) ;");
		System.out.println();
	}
}

