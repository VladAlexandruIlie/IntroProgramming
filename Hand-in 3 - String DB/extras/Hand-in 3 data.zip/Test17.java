
import java.util.*;
import java.lang.reflect.*;

public class Test17 {
	public static void main(String[] args) {
		StringDB db = new StringDB();
		db.execute("INSERT INTO customers VALUES ( '3' , 'Antonio_Moreno_Taquería' , 'Antonio_Moreno' , 'Mataderos_2312' , 'México_D.F.' , '05023' , 'Mexico' ) ;");
		System.out.println();
	}
}

