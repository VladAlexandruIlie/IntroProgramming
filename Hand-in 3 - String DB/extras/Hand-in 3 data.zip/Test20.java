
import java.util.*;
import java.lang.reflect.*;

public class Test20 {
	public static void main(String[] args) {
		StringDB db = new StringDB();
		db.execute("INSERT INTO orders VALUES ( '10310' , '77' , '8' , '1996-09-20' , '2' ) ;");
		System.out.println();
	}
}

