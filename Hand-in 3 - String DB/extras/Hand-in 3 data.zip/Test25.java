
import java.util.*;
import java.lang.reflect.*;

public class Test25 {
	public static void main(String[] args) {
		StringDB db = new StringDB();
		db.execute("SELECT * INTO foo FROM bar INNER JOIN baz ON onething = another ;");
		System.out.println();
	}
}

