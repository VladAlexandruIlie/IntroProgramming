
import java.util.*;
import java.lang.reflect.*;

public class Test18 {
	public static void main(String[] args) {
		StringDB db = new StringDB();
		db.execute("INSERT INTO orders VALUES ( '10308' , '2' , '7' , '1996-09-18' , '3' ) ;");
		System.out.println();
	}
}

