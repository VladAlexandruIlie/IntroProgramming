
import java.util.*;
import java.lang.reflect.*;

public class Test23 {
	public static void main(String[] args) {
		StringDB db = new StringDB();
		db.execute("SELECT CustomerName AS real_name , Country AS dominion , ContactName AS who_we_gonna_call INTO mytable FROM customers ;");
		System.out.println();
	}
}

