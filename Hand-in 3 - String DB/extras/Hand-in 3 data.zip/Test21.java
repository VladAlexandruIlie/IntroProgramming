
import java.util.*;
import java.lang.reflect.*;

public class Test21 {
	public static void main(String[] args) {
		StringDB db = new StringDB();
		db.execute("SELECT name AS alias INTO secret_identity FROM teachers ;");
		System.out.println();
	}
}

