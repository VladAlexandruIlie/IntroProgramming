
import java.util.*;
import java.lang.reflect.*;

public class Test08 {
	public static void main(String[] args) {
		StringDB db = new StringDB();
		db.execute("CREATE TABLE courses ( coursename varchar ) ;");
		System.out.println();
	}
}

