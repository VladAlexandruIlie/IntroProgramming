
import java.util.*;
import java.lang.reflect.*;

public class ForestTest02 {
	public static void main(String[] args) {
		checkField(Tree.class, "height", double.class);
	}

	static String getTypesAsString(Class<?> ... parameters) {
		StringBuilder sb = new StringBuilder("(");
		for (Class<?> c : parameters) {
			if (sb.length() > 0) sb.append(", ");
			sb.append(c.getSimpleName());
		}
		return sb.append(")").toString();
	}

	static void checkContructor(Class<?> c, Class<?> ... parameters) {
		try {
			Constructor<?> constructor = c.getDeclaredConstructor(parameters);
			if (constructor.getModifiers() != Modifier.PUBLIC) {
				System.out.println("The constructor of " + c.getName() + " should be public!");
			} else {
				System.out.println("The constructor of " + c.getName() + " has the right signature.");
			}
		} catch (NoSuchMethodException e) {
			System.out.println(c.getName() + " does not have the constructor " + c.getName() + getTypesAsString(parameters));
		}
	}

	static void checkMethod(Class<?> c, Type returnType, String methodName, Class<?> ... parameters) {
		try {
			Method method = c.getDeclaredMethod(methodName, parameters);
			if (method.getReturnType() != void.class) {
				System.out.println(c.getName() + "." + methodName + " should have void return type.");
			} else if (method.getModifiers() != Modifier.PUBLIC) {
				System.out.println(c.getName() + "." + methodName + " should be public!");
			} else {
				System.out.println(c.getName() + "." + methodName + " has a correct signature.");
			}
		} catch (NoSuchMethodException e) {
			System.out.println(c.getName() + " does not have the method " + methodName + getTypesAsString(parameters));
		}
	}

	static void checkField(Class<?> c, String fieldName, Type desiredType) {
		try {
			Field field = c.getDeclaredField(fieldName);
			int modifiers = field.getModifiers();
			Type declaredType = field.getType();
			if (!declaredType.equals(desiredType)) {
				System.out.println(c.getName() + "." + fieldName + " is declared as having type " + declaredType + ", but it should have been a " + desiredType);
			} else if (Modifier.isStatic(modifiers)) {
				System.out.println(c.getName() + "." + fieldName + " is declared as static, but it shouldn't be!");
			} else if (!Modifier.isPrivate(modifiers)) {
				System.out.println(c.getName() + "." + fieldName + " is not declared as private, but it should be!");
			} else if (Modifier.isVolatile(modifiers)) {
				System.out.println(c.getName() + "." + fieldName + " is declared as volatile... What is wrong with you?");
			} else if (Modifier.isTransient(modifiers)) {
				System.out.println(c.getName() + "." + fieldName + " is declared as transient... What is wrong with you?");
			} else {
				System.out.println(c.getName() + "." + fieldName + " is fine.");
			}
		} catch (NoSuchFieldException e) {
			System.out.println(c.getName() + " does not have a field called " + fieldName);
		}
	}
}

