import java.io.IOException;

public class Test01 {
	public static void main(String[] args) {
		CashRegister cashRegister = new CashRegister("prices.txt", "discounts.txt");
		cashRegister.printReceipt("bar1.txt");
	}
}

