import java.io.IOException;

public class Test03 {
	public static void main(String[] args) {
		CashRegister cashRegister = new CashRegister("prices.txt", "discounts.txt");
		cashRegister.printReceipt("bar3.txt");
	}
}

