import java.io.IOException;

public class Test07 {
	public static void main(String[] args) {
		CashRegister cashRegister = new CashRegister("prices.txt", "discounts.txt");
		cashRegister.printReceipt("bar0.txt");
	}
}

